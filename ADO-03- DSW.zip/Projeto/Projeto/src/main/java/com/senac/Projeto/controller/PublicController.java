package com.senac.Projeto.controller;

import com.senac.Projeto.repository.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

// Critério ADO 3: Controller para a área não logada (visão pública)
@Controller
public class PublicController {

    @Autowired
    private ItemRepository itemRepository;

    // Rota GET para a página inicial (Área Não Logada)
    // Retorna a view em 'templates/publica/index.html'
    @GetMapping("/")
    public String index(Model model) {
        // Exibe a listagem de itens para o visitante
        model.addAttribute("itens", itemRepository.findAll());
        return "publica/index";
    }
}