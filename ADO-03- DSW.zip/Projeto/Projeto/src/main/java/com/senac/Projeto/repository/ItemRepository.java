package com.senac.Projeto.repository;

import com.senac.Projeto.model.Item;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

// Critério ADO 3: Utilizar JPA
@Repository
public interface ItemRepository extends JpaRepository<Item, Long> {
    // Métodos CRUD básicos fornecidos pelo JpaRepository
}