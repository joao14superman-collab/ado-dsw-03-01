package com.senac.Projeto.controller;

import com.senac.Projeto.model.Item;
import com.senac.Projeto.repository.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;

// Critério ADO 3: Controller para a área logada (visão administrativa)
@Controller
@RequestMapping("/admin") // Todas as rotas administrativas
public class AdminController {

    @Autowired
    private ItemRepository itemRepository;

    // Rota GET: Listar todos os itens (Dashboard)
    @GetMapping
    public String dashboard(Model model) {
        model.addAttribute("itens", itemRepository.findAll());
        return "admin/dashboard"; // templates/admin/dashboard.html
    }

    // Rota GET: Formulário de Novo Item
    @GetMapping("/novo")
    public String formNovo(Item item) {
        return "admin/form"; // templates/admin/form.html
    }

    // Rota POST: Salvar Novo ou Editar Item (Critério: Operação funcional POST)
    @PostMapping("/salvar")
    // Critério ADO 3: Utiliza @Valid para Bean Validation
    public String salvar(@Valid Item item, BindingResult result, RedirectAttributes attributes) {
        if (result.hasErrors()) {
            return "admin/form"; // Erros de validação, retorna ao formulário
        }
        itemRepository.save(item);
        attributes.addFlashAttribute("mensagem", "Item salvo com sucesso!");
        return "redirect:/admin";
    }

    // Rota GET: Formulário de Edição
    @GetMapping("/editar/{id}")
    public String formEditar(@PathVariable("id") Long id, Model model) {
        Item item = itemRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("ID inválido: " + id));
        model.addAttribute("item", item);
        return "admin/form"; // templates/admin/form.html
    }

    // Rota GET: Excluir Item (Critério: Operação funcional GET/POST)
    // Para simplicidade, usaremos GET, mas em produção POST/DELETE é recomendado.
    @GetMapping("/excluir/{id}")
    public String excluir(@PathVariable("id") Long id, RedirectAttributes attributes) {
        itemRepository.deleteById(id);
        attributes.addFlashAttribute("mensagem", "Item excluído com sucesso!");
        return "redirect:/admin";
    }
}